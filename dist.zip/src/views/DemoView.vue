<script setup>
  import HeroOffline from '@/components/hero_offline.vue'
</script>
<template>
  <HeroOffline />
</template>