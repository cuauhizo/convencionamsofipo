<template>
  <section id="section6" class="container grid gap-12 justify-items-center items-center py-10 md:py-20 lg:grid-cols-2" data-aos-anchor-placement="center-bottom">
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4 order-2 lg:order-1">
      <div class="overflow-hidden rounded-lg" data-aos="flip-right" data-aos-duration="500">
        <img class="h-auto max-w-full rounded-lg transition-transform hover:rotate-2 hover:scale-110" width="201" height="156" loading="lazy" src="@/assets/img/galeria/imagen1.png" alt="Gallery image" />
      </div>
      <div class="overflow-hidden rounded-lg" data-aos="flip-right" data-aos-duration="1000">
        <img class="h-auto max-w-full rounded-lg transition-transform hover:rotate-2 hover:scale-110" width="201" height="156" loading="lazy" src="@/assets/img/galeria/imagen2.png" alt="Gallery image" />
      </div>
      <div class="overflow-hidden rounded-lg" data-aos="flip-right" data-aos-duration="1500">
        <img class="h-auto max-w-full rounded-lg transition-transform hover:rotate-2 hover:scale-110" width="201" height="156" loading="lazy" src="@/assets/img/galeria/imagen3.png" alt="Gallery image" />
      </div>
      <div class="overflow-hidden rounded-lg" data-aos="flip-right" data-aos-duration="2000">
        <img class="h-auto max-w-full rounded-lg transition-transform hover:rotate-2 hover:scale-110" width="201" height="156" loading="lazy" src="@/assets/img/galeria/imagen4.png" alt="Gallery image" />
      </div>
      <div class="overflow-hidden rounded-lg" data-aos="flip-right" data-aos-duration="2500">
        <img class="h-auto max-w-full rounded-lg transition-transform hover:rotate-2 hover:scale-110" width="201" height="156" loading="lazy" src="@/assets/img/galeria/imagen5.png" alt="Gallery image" />
      </div>
      <div class="overflow-hidden rounded-lg" data-aos="flip-right" data-aos-duration="3000">
        <img class="h-auto max-w-full rounded-lg transition-transform hover:rotate-2 hover:scale-110" width="201" height="156" loading="lazy" src="@/assets/img/galeria/imagen6.png" alt="Gallery image" />
      </div>
    </div>
    <div class="order-1 ld:order-2" data-aos="fade-up" data-aos-anchor-placement="center-bottom">
      <h2 class="titulo-seccion">Sede</h2>
      <p class="titulo">
          Hotel Sumiya
      </p>
      <p class="mb-6">Interior Fraccionamiento, Cam. Real a Sumiya S/N, Jose G. Parres, C. P. 62564 Jiutepec, Morelos.</p>
      <div class="hidden">
        <button class="flex gap-2 rounded-full transition-all duration-500 font-lemon-normal text-xs justify-center items-center bg-gradient-to-r from-[#4D008C] to-[#C028B9] hover:bg-gradient-to-br px-8 py-2">
          Conoce los costos
        </button>
      </div>
    </div>
  </section>
</template>

<script setup>

</script>


<style>

</style>